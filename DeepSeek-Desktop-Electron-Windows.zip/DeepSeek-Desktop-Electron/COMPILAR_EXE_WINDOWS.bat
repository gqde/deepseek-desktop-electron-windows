@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>&1
if errorlevel 1 (
  echo ERROR: Instala Node.js LTS desde https://nodejs.org/.
  pause
  exit /b 1
)
if not exist "node_modules\electron\package.json" (
  call npm install
  if errorlevel 1 (
    echo Error al instalar dependencias.
    pause
    exit /b 1
  )
)
call npm test
if errorlevel 1 (
  echo ERROR: Las pruebas han fallado.
  pause
  exit /b 1
)
call npm run dist:win
if errorlevel 1 (
  echo ERROR: No fue posible generar el instalador.
  pause
  exit /b 1
)
echo.
echo Listo. Revisa la carpeta dist: instalador y portable .exe
start "" "%~dp0dist"
pause
endlocal
