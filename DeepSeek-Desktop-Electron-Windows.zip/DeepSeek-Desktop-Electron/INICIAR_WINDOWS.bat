@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>&1
if errorlevel 1 (
  echo ERROR: Instala Node.js LTS desde https://nodejs.org/ y vuelve a abrir esta consola.
  pause
  exit /b 1
)
if not exist "node_modules\electron\package.json" (
  echo Instalando dependencias por primera vez...
  call npm install
  if errorlevel 1 (
    echo Error al instalar dependencias. Comprueba internet.
    pause
    exit /b 1
  )
)
call npm start
if errorlevel 1 pause
endlocal
