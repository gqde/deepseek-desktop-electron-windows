# DeepSeek Desktop Personal (Electron, Windows)

Aplicación de escritorio **no oficial** para abrir [chat.deepseek.com](https://chat.deepseek.com/) en su propia ventana, conservando los datos de inicio de sesión de **esta aplicación** entre cierres y reaperturas.

**No es una copia del sitio:** visualiza el servicio web real de DeepSeek. Se requiere conexión a Internet. La apariencia y funciones dependen de DeepSeek.

## Funciones

- Ventana propia en Windows con menú, recarga, zoom y pantalla completa.
- **Sesión persistente**, en `persist:deepseek-account`: cookies, almacenamiento web y caché quedan guardados localmente en el perfil Electron.
- Botón **DeepSeek → Borrar sesión local** para cerrar y limpiar el perfil (sin eliminar la cuenta ni conversaciones del servidor).
- Enlaces externos HTTPS abiertos en el navegador predeterminado.
- Sin contraseñas en código; sin extracción o reutilización de cookies de Chrome/Edge.
- Aislamiento de procesos y contexto, sin Node.js en la página, sin preload privilegiado.
- Dos variantes de salida: instalador `.exe` y versión portable `.exe`.

## Requisitos en Windows

- Windows 10/11 **de 64 bits**.
- [Node.js LTS](https://nodejs.org/) instalado (contiene npm), recomendado Node.js 22 o superior.
- Internet para instalar paquetes y usar DeepSeek.

## Empezar (sin instalar el .exe)

1. Extrae el ZIP a una carpeta, por ejemplo `C:\Proyectos\DeepSeek-Desktop-Electron`.
2. Haz doble clic en `INICIAR_WINDOWS.bat` **o**, en PowerShell/VS Code:

   ```powershell
   cd C:\Proyectos\DeepSeek-Desktop-Electron
   npm install
   npm start
   ```

3. En la ventana oficial de DeepSeek, inicia sesión **una sola vez** con tu cuenta.
4. Cierra completamente la app y vuelve a abrirla. La sesión puede mantenerse hasta que DeepSeek la invalide o expire.

## Generar los `.exe` para Windows

Haz doble clic en `COMPILAR_EXE_WINDOWS.bat` o ejecuta:

```powershell
npm install
npm test
npm run dist:win
```

Al finalizar, en `dist/` aparecerán, si la compilación tiene éxito:

- `DeepSeek-Desktop-Setup-1.0.0.exe` — instalador NSIS.
- `DeepSeek-Desktop-Portable-1.0.0.exe` — versión portable (sin instalador).

**Importante:** No están firmados digitalmente; Windows SmartScreen podría advertir que el editor es desconocido. Para distribuir públicamente necesitas firma de código y pruebas adicionales.

## Cómo funciona la sesión

Electron usa una partición persistente (`persist:deepseek-account`). Al abrirse utiliza el **mismo perfil local** cada vez que se inicia la app, de forma que las cookies y el almacenamiento web se conservan aunque cierres el programa. El inicio de sesión se hace solamente a través de la web oficial.

- **No** importa automáticamente la sesión ya iniciada en Chrome, Edge o Firefox.
- **No** garantiza sesión perpetua: DeepSeek podría exigir nuevo login, 2FA, CAPTCHA o cerrar sesiones.
- Si usas Google o Apple para ingresar, su proveedor puede **bloquear los navegadores integrados**, independientemente del código de Electron. Prueba el inicio de sesión directo de DeepSeek si está disponible. No se intenta evadir controles de seguridad.
- Se usa `https://chat.deepseek.com/`, que puede cambiar y romper la compatibilidad sin aviso.

## Seguridad y privacidad

- La sesión y los datos del servicio se guardan dentro del perfil privado que usa Electron en tu usuario de Windows, por ejemplo bajo `%APPDATA%\deepseek-desktop-personal` o un nombre de aplicación equivalente (la ubicación real depende de Electron/packaging).
- **No compartas esa carpeta**, ni la publiques en Git. Contiene cookies y datos sensibles de navegación.
- Los mensajes y conversaciones son procesados por DeepSeek conforme a sus propios términos; este proyecto **no agrega un servidor intermediario**.
- La app no recopila credenciales ni exporta datos de sesión.
- Se bloquean ventanas y protocolos inesperados; solo se permite navegación integrada a dominios de DeepSeek y a un conjunto acotado de proveedores de login.
- Se rechazan permisos de micrófono, cámara, ubicación y notificaciones. Algunas funciones del sitio que los requieran no operarán.
- Para limpiar **por completo** los datos locales, utiliza la opción integrada de borrar sesión y cierra el programa. No borres manualmente archivos mientras se ejecuta.
- Usa siempre versiones actualizadas de Electron y las dependencias si vas a redistribuirla.

## Estructura

```text
DeepSeek-Desktop-Electron/
├─ assets/
│  ├─ icon.ico
│  └─ icon.png
├─ src/
│  ├─ main.js               # Ventana, menús, sesión persistente, seguridad
│  └─ security.js           # Validación de URLs
├─ tests/
│  └─ security.test.js
├─ package.json
├─ INICIAR_WINDOWS.bat
├─ COMPILAR_EXE_WINDOWS.bat
├─ .gitignore
└─ README.md
```

## Solución de problemas

- **`node` no se reconoce**: instala Node.js LTS, cierra y abre la terminal.
- **`npm install` falla**: comprueba Internet, firewall y acceso a npm/GitHub (Electron descarga binarios).
- **Pantalla vacía o CAPTCHA**: menú `Ver → Recargar`; confirma que puedes abrir [DeepSeek](https://chat.deepseek.com/) en Chrome/Edge. La web puede restringir Electron.
- **Se pierde sesión**: no ejecutes el programa con diferentes usuarios de Windows o perfiles efímeros. Comprueba si DeepSeek caducó la cookie.
- **Google/Apple no deja acceder**: las políticas del proveedor pueden prohibir la autenticación en un navegador integrado. No hay transferencia automática de sesión entre Chrome/Edge y Electron.
- **SmartScreen**: prueba solo ejecutables que hayas compilado tú; para distribución firma el código con certificado válido.

## Notas de compilación

El proyecto trae **código fuente y configuración**, no trae `node_modules/`. La compilación y la verificación de login real deben efectuarse en una máquina Windows con Internet. No está afiliado, respaldado ni distribuido por DeepSeek.

### Fuentes técnicas

- [Sesiones de Electron](https://www.electronjs.org/docs/latest/api/session) — `persist:`.
- [Recomendaciones de seguridad de Electron](https://www.electronjs.org/docs/latest/tutorial/security).
- [Electron Builder, target NSIS](https://www.electron.build/v26/docs/nsis/).
