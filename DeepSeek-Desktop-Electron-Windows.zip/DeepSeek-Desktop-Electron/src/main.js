// DeepSeek Desktop Personal — cliente de escritorio NO oficial.
// No captura contraseñas, no copia cookies de otros navegadores, no inyecta JS.
const { app, BrowserWindow, Menu, dialog, session, shell } = require('electron');
const { isDeepSeekUrl, isTrustedNavigation, isSafeExternalUrl } = require('./security');

const URL_INICIO = 'https://chat.deepseek.com/';
const PARTICION = 'persist:deepseek-account'; // persist: conserva cookies, localStorage y otros datos.
const APP_ID = 'com.personal.deepseekdesktop';
let mainWindow = null;

app.setName('DeepSeek Desktop Personal');
if (process.platform === 'win32') app.setAppUserModelId(APP_ID);

function abrirEnNavegador(raw) {
  if (isSafeExternalUrl(raw)) shell.openExternal(raw).catch(() => {});
}

function configureWebContents(contents) {
  // Nunca abandonar el conjunto de destinos permitidos dentro de la app.
  function comprobarNavegacion(event, raw) {
    if (isTrustedNavigation(raw)) return;
    event.preventDefault();
    abrirEnNavegador(raw);
  }
  contents.on('will-navigate', comprobarNavegacion);
  contents.on('will-redirect', (event, raw) => {
    // Bloquea redirecciones fuera de DeepSeek/proveedores de login.
    if (!isTrustedNavigation(raw)) event.preventDefault();
  });

  contents.setWindowOpenHandler(({ url }) => {
    if (isTrustedNavigation(url)) {
      return {
        action: 'allow',
        overrideBrowserWindowOptions: {
          title: 'Inicio de sesión',
          width: 540,
          height: 760,
          minWidth: 360,
          minHeight: 420,
          autoHideMenuBar: true,
          backgroundColor: '#111c2f',
          webPreferences: {
            partition: PARTICION,
            nodeIntegration: false,
            contextIsolation: true,
            sandbox: true,
            webviewTag: false
          }
        }
      };
    }
    // Un enlace convencional a un sitio externo se abre en el navegador predeterminado.
    abrirEnNavegador(url);
    return { action: 'deny' };
  });

  contents.on('did-create-window', (popup) => {
    popup.setMenuBarVisibility(false);
    configureWebContents(popup.webContents);
  });
}

async function borrarSesionLocal() {
  const respuesta = await dialog.showMessageBox(mainWindow, {
    type: 'warning',
    buttons: ['Cancelar', 'Borrar sesión'],
    defaultId: 0,
    cancelId: 0,
    title: 'Eliminar sesión local',
    message: '¿Eliminar las cookies y datos locales de DeepSeek?',
    detail: 'Tendrás que volver a iniciar sesión en esta aplicación. Esto no elimina tu cuenta ni tus conversaciones almacenadas en DeepSeek.'
  });
  if (respuesta.response !== 1) return;
  const ses = session.fromPartition(PARTICION);
  await ses.clearStorageData();
  await ses.clearCache();
  if (mainWindow && !mainWindow.isDestroyed()) await mainWindow.loadURL(URL_INICIO);
}

function instalarMenu() {
  Menu.setApplicationMenu(Menu.buildFromTemplate([
    {
      label: 'DeepSeek',
      submenu: [
        { label: 'Abrir inicio', accelerator: 'Alt+Home', click: () => mainWindow?.loadURL(URL_INICIO) },
        { label: 'Abrir en navegador externo', click: () => abrirEnNavegador(URL_INICIO) },
        { type: 'separator' },
        { label: 'Borrar sesión local', click: () => borrarSesionLocal().catch((e) => dialog.showErrorBox('Error al borrar sesión', e.message)) },
        { type: 'separator' },
        { role: 'quit', label: 'Salir' }
      ]
    },
    { label: 'Editar', submenu: [
      { role: 'undo', label: 'Deshacer' },
      { role: 'redo', label: 'Rehacer' },
      { type: 'separator' },
      { role: 'cut', label: 'Cortar' },
      { role: 'copy', label: 'Copiar' },
      { role: 'paste', label: 'Pegar' },
      { role: 'selectAll', label: 'Seleccionar todo' }
    ]},
    { label: 'Ver', submenu: [
      { role: 'reload', label: 'Recargar' },
      { role: 'forceReload', label: 'Recarga forzada' },
      { type: 'separator' },
      { role: 'resetZoom', label: 'Restablecer zoom' },
      { role: 'zoomIn', label: 'Acercar' },
      { role: 'zoomOut', label: 'Alejar' },
      { type: 'separator' },
      { role: 'togglefullscreen', label: 'Pantalla completa' }
    ]},
    { label: 'Ayuda', submenu: [
      { label: 'Acerca de', click: () => dialog.showMessageBox(mainWindow, {
        type: 'info', buttons: ['Cerrar'], title: 'Acerca de DeepSeek Desktop Personal',
        message: 'DeepSeek Desktop Personal v' + app.getVersion(),
        detail: 'Cliente independiente, no oficial. Muestra https://chat.deepseek.com/ y conserva la sesión en un perfil local de Electron.'
      }) }
    ]}
  ]));
}

function crearVentana() {
  mainWindow = new BrowserWindow({
    title: 'DeepSeek Desktop Personal',
    width: 1260,
    height: 840,
    minWidth: 740,
    minHeight: 520,
    show: false,
    autoHideMenuBar: true,
    backgroundColor: '#111c2f',
    icon: require('path').join(__dirname, '..', 'assets', 'icon.png'),
    webPreferences: {
      partition: PARTICION,
      nodeIntegration: false,
      contextIsolation: true,
      sandbox: true,
      webviewTag: false,
      allowRunningInsecureContent: false,
      webSecurity: true
    }
  });

  configureWebContents(mainWindow.webContents);
  mainWindow.once('ready-to-show', () => mainWindow?.show());
  // Evitar ventana oculta permanente ante fallos de red y errores de carga.
  mainWindow.webContents.on('did-fail-load', (_event, code, _desc, _url, isMainFrame) => {
    if (isMainFrame && code !== -3 && !mainWindow.isDestroyed()) mainWindow.show();
  });
  mainWindow.on('closed', () => { mainWindow = null; });
  mainWindow.loadURL(URL_INICIO).catch((error) => {
    if (mainWindow && !mainWindow.isDestroyed()) mainWindow.show();
    dialog.showErrorBox('No se pudo cargar DeepSeek', `${error.message}\n\nComprueba tu conexión y usa Ver → Recargar.`);
  });
  instalarMenu();
}

const bloqueo = app.requestSingleInstanceLock();
if (!bloqueo) {
  app.quit();
} else {
  app.on('second-instance', () => {
    if (mainWindow && !mainWindow.isDestroyed()) {
      if (mainWindow.isMinimized()) mainWindow.restore();
      mainWindow.focus();
    }
  });

  app.whenReady().then(() => {
    const ses = session.fromPartition(PARTICION);
    // No concedemos acceso a cámara, micrófono, ubicación ni notificaciones.
    ses.setPermissionRequestHandler((webContents, permission, callback) => {
      callback(permission === 'clipboard-sanitized-write' && isDeepSeekUrl(webContents.getURL()));
    });
    ses.setPermissionCheckHandler((webContents, permission) => {
      return permission === 'clipboard-sanitized-write' && Boolean(webContents && isDeepSeekUrl(webContents.getURL()));
    });

    // Prohíbe crear webviews no controladas, incluso si el sitio lo solicita.
    app.on('web-contents-created', (_event, contents) => {
      contents.on('will-attach-webview', (event) => event.preventDefault());
    });

    crearVentana();
    app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) crearVentana(); });
  }).catch((error) => dialog.showErrorBox('Error de inicio', error.message));
  app.on('window-all-closed', () => app.quit());
}
