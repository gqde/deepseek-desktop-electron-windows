// La app trata todo contenido remoto como no confiable.
// Lista de navegación reducida: DeepSeek y proveedores de inicio de sesión habituales.
const DEEPSEEK_HOST = 'deepseek.com';
const AUTH_HOSTS = new Set(['accounts.google.com', 'appleid.apple.com']);

function parseHttps(raw) {
  try {
    const url = new URL(raw);
    if (url.protocol !== 'https:' || url.username || url.password) return null;
    return url;
  } catch {
    return null;
  }
}

function isDeepSeekUrl(raw) {
  const url = parseHttps(raw);
  return Boolean(url && (url.hostname === DEEPSEEK_HOST || url.hostname.endsWith('.' + DEEPSEEK_HOST)));
}

function isTrustedNavigation(raw) {
  const url = parseHttps(raw);
  return Boolean(url && (isDeepSeekUrl(raw) || AUTH_HOSTS.has(url.hostname)));
}

function isSafeExternalUrl(raw) {
  // Nunca pasar protocolos como file:, javascript:, shell:, ms-*, etc. a shell.openExternal.
  return Boolean(parseHttps(raw));
}

module.exports = { isDeepSeekUrl, isTrustedNavigation, isSafeExternalUrl };
