const test = require('node:test');
const assert = require('node:assert/strict');
const { isDeepSeekUrl, isTrustedNavigation, isSafeExternalUrl } = require('../src/security');

test('acepta DeepSeek oficial', () => {
  assert.equal(isDeepSeekUrl('https://chat.deepseek.com/'), true);
  assert.equal(isDeepSeekUrl('https://login.deepseek.com/path'), true);
  assert.equal(isDeepSeekUrl('https://deepseek.com/'), true);
});
test('evita suplantación de dominios y protocolos', () => {
  for (const url of [
    'https://chat.deepseek.com.malicioso.tld/',
    'https://deepseek.com@evil.tld/',
    'http://chat.deepseek.com/',
    'javascript:alert(1)',
    'file:///C:/Windows/system.ini',
    'https://deepseek.com.evil.tld/',
    'https://evil.tld/',
    'about:blank'
  ]) assert.equal(isDeepSeekUrl(url), false, url);
});
test('permite navegación de autenticación bajo whitelist', () => {
  assert.equal(isTrustedNavigation('https://accounts.google.com/o/oauth2/v2/auth'), true);
  assert.equal(isTrustedNavigation('https://appleid.apple.com/auth/authorize'), true);
  assert.equal(isTrustedNavigation('https://accounts.google.com.evil.tld/'), false);
});
test('solo abre externamente HTTPS sin credenciales en URL', () => {
  assert.equal(isSafeExternalUrl('https://www.wikipedia.org/'), true);
  assert.equal(isSafeExternalUrl('file:///tmp/a'), false);
  assert.equal(isSafeExternalUrl('mailto:test@example.com'), false);
  assert.equal(isSafeExternalUrl('https://usuario:secret@ejemplo.com/'), false);
});
